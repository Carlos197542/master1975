package app.condominio.domain.enums;

public enum Autorizacao {
	ADMIN,
	SINDICO,
	CONDOMINO;
}